#!/usr/local/bin/python3
import matplotlib.pyplot as plt
import numpy as np

data = []
with open('_data.dat', 'r') as f:
    for line in f:
        x, y = line.split("\t")
        data.append((float(x), float(y)))

x = [point[0] for point in data]
y = [point[1] for point in data]

plt.plot(x, y,marker="o")

# plt.scatter(x, y, linestyle='-', marker='o')
plt.show()


